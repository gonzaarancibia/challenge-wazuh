"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.TodoPlugin = void 0;
var _routes = require("./routes");
function _defineProperty(obj, key, value) { key = _toPropertyKey(key); if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
function _toPropertyKey(arg) { var key = _toPrimitive(arg, "string"); return typeof key === "symbol" ? key : String(key); }
function _toPrimitive(input, hint) { if (typeof input !== "object" || input === null) return input; var prim = input[Symbol.toPrimitive]; if (prim !== undefined) { var res = prim.call(input, hint || "default"); if (typeof res !== "object") return res; throw new TypeError("@@toPrimitive must return a primitive value."); } return (hint === "string" ? String : Number)(input); }
class TodoPlugin {
  constructor(initializerContext) {
    _defineProperty(this, "logger", void 0);
    this.logger = initializerContext.logger.get();
  }
  async setup(core) {
    this.logger.debug('todo_plugin: Setup');
    // Esperar a que OpenSearch esté disponible
    await core.opensearch.waitUntilReady();
    const router = core.http.createRouter();

    // Register server side APIs
    (0, _routes.defineRoutes)(router);

    // Initialize OpenSearch index if it doesn't exist
    await this.initializeIndex(core);
    return {};
  }
  async initializeIndex(core) {
    try {
      const client = core.opensearch.client.asCurrentUser;
      const indexExists = await client.indices.exists({
        index: 'todos'
      });
      if (!indexExists.body) {
        await client.indices.create({
          index: 'todos',
          body: {
            mappings: {
              properties: {
                title: {
                  type: 'text'
                },
                status: {
                  type: 'keyword'
                },
                createdAt: {
                  type: 'date'
                },
                completedAt: {
                  type: 'date'
                },
                errorAt: {
                  type: 'date'
                },
                assignee: {
                  type: 'keyword'
                },
                description: {
                  type: 'text'
                },
                tags: {
                  type: 'keyword'
                }
              }
            }
          }
        });
        this.logger.debug('todo_plugin: Created todos index');
      }
    } catch (error) {
      this.logger.error('Failed to initialize todos index:', error);
      throw error; // Re-throw to ensure setup fails if index creation fails
    }
  }

  start(core) {
    this.logger.debug('todo_plugin: Started');
    return {};
  }
  stop() {}
}
exports.TodoPlugin = TodoPlugin;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcm91dGVzIiwicmVxdWlyZSIsIl9kZWZpbmVQcm9wZXJ0eSIsIm9iaiIsImtleSIsInZhbHVlIiwiX3RvUHJvcGVydHlLZXkiLCJPYmplY3QiLCJkZWZpbmVQcm9wZXJ0eSIsImVudW1lcmFibGUiLCJjb25maWd1cmFibGUiLCJ3cml0YWJsZSIsImFyZyIsIl90b1ByaW1pdGl2ZSIsIlN0cmluZyIsImlucHV0IiwiaGludCIsInByaW0iLCJTeW1ib2wiLCJ0b1ByaW1pdGl2ZSIsInVuZGVmaW5lZCIsInJlcyIsImNhbGwiLCJUeXBlRXJyb3IiLCJOdW1iZXIiLCJUb2RvUGx1Z2luIiwiY29uc3RydWN0b3IiLCJpbml0aWFsaXplckNvbnRleHQiLCJsb2dnZXIiLCJnZXQiLCJzZXR1cCIsImNvcmUiLCJkZWJ1ZyIsIm9wZW5zZWFyY2giLCJ3YWl0VW50aWxSZWFkeSIsInJvdXRlciIsImh0dHAiLCJjcmVhdGVSb3V0ZXIiLCJkZWZpbmVSb3V0ZXMiLCJpbml0aWFsaXplSW5kZXgiLCJjbGllbnQiLCJhc0N1cnJlbnRVc2VyIiwiaW5kZXhFeGlzdHMiLCJpbmRpY2VzIiwiZXhpc3RzIiwiaW5kZXgiLCJib2R5IiwiY3JlYXRlIiwibWFwcGluZ3MiLCJwcm9wZXJ0aWVzIiwidGl0bGUiLCJ0eXBlIiwic3RhdHVzIiwiY3JlYXRlZEF0IiwiY29tcGxldGVkQXQiLCJlcnJvckF0IiwiYXNzaWduZWUiLCJkZXNjcmlwdGlvbiIsInRhZ3MiLCJlcnJvciIsInN0YXJ0Iiwic3RvcCIsImV4cG9ydHMiXSwic291cmNlcyI6WyJwbHVnaW4udHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgUGx1Z2luSW5pdGlhbGl6ZXJDb250ZXh0LFxuICBDb3JlU2V0dXAsXG4gIENvcmVTdGFydCxcbiAgUGx1Z2luLFxuICBMb2dnZXIsXG59IGZyb20gJy4uLy4uLy4uL3NyYy9jb3JlL3NlcnZlcic7XG5cbmltcG9ydCB7IFRvZG9QbHVnaW5TZXR1cCwgVG9kb1BsdWdpblN0YXJ0IH0gZnJvbSAnLi90eXBlcyc7XG5pbXBvcnQgeyBkZWZpbmVSb3V0ZXMgfSBmcm9tICcuL3JvdXRlcyc7XG5cbmV4cG9ydCBjbGFzcyBUb2RvUGx1Z2luXG4gIGltcGxlbWVudHMgUGx1Z2luPFRvZG9QbHVnaW5TZXR1cCwgVG9kb1BsdWdpblN0YXJ0PiB7XG4gIHByaXZhdGUgcmVhZG9ubHkgbG9nZ2VyOiBMb2dnZXI7XG5cbiAgY29uc3RydWN0b3IoaW5pdGlhbGl6ZXJDb250ZXh0OiBQbHVnaW5Jbml0aWFsaXplckNvbnRleHQpIHtcbiAgICB0aGlzLmxvZ2dlciA9IGluaXRpYWxpemVyQ29udGV4dC5sb2dnZXIuZ2V0KCk7XG4gIH1cblxuICBwdWJsaWMgYXN5bmMgc2V0dXAoY29yZTogQ29yZVNldHVwKSB7XG4gICAgdGhpcy5sb2dnZXIuZGVidWcoJ3RvZG9fcGx1Z2luOiBTZXR1cCcpO1xuICAgIC8vIEVzcGVyYXIgYSBxdWUgT3BlblNlYXJjaCBlc3TDqSBkaXNwb25pYmxlXG4gICAgYXdhaXQgY29yZS5vcGVuc2VhcmNoLndhaXRVbnRpbFJlYWR5KCk7XG5cbiAgICBjb25zdCByb3V0ZXIgPSBjb3JlLmh0dHAuY3JlYXRlUm91dGVyKCk7XG5cbiAgICAvLyBSZWdpc3RlciBzZXJ2ZXIgc2lkZSBBUElzXG4gICAgZGVmaW5lUm91dGVzKHJvdXRlcik7XG5cbiAgICAvLyBJbml0aWFsaXplIE9wZW5TZWFyY2ggaW5kZXggaWYgaXQgZG9lc24ndCBleGlzdFxuICAgIGF3YWl0IHRoaXMuaW5pdGlhbGl6ZUluZGV4KGNvcmUpO1xuXG4gICAgcmV0dXJuIHt9O1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBpbml0aWFsaXplSW5kZXgoY29yZTogQ29yZVNldHVwKSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGNsaWVudCA9IGNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlcjtcblxuICAgICAgY29uc3QgaW5kZXhFeGlzdHMgPSBhd2FpdCBjbGllbnQuaW5kaWNlcy5leGlzdHMoeyBpbmRleDogJ3RvZG9zJyB9KTtcblxuICAgICAgaWYgKCFpbmRleEV4aXN0cy5ib2R5KSB7XG4gICAgICAgIGF3YWl0IGNsaWVudC5pbmRpY2VzLmNyZWF0ZSh7XG4gICAgICAgICAgaW5kZXg6ICd0b2RvcycsXG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgbWFwcGluZ3M6IHtcbiAgICAgICAgICAgICAgcHJvcGVydGllczoge1xuICAgICAgICAgICAgICAgIHRpdGxlOiB7IHR5cGU6ICd0ZXh0JyB9LFxuICAgICAgICAgICAgICAgIHN0YXR1czogeyB0eXBlOiAna2V5d29yZCcgfSxcbiAgICAgICAgICAgICAgICBjcmVhdGVkQXQ6IHsgdHlwZTogJ2RhdGUnIH0sXG4gICAgICAgICAgICAgICAgY29tcGxldGVkQXQ6IHsgdHlwZTogJ2RhdGUnIH0sXG4gICAgICAgICAgICAgICAgZXJyb3JBdDogeyB0eXBlOiAnZGF0ZScgfSxcbiAgICAgICAgICAgICAgICBhc3NpZ25lZTogeyB0eXBlOiAna2V5d29yZCcgfSxcbiAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogeyB0eXBlOiAndGV4dCcgfSxcbiAgICAgICAgICAgICAgICB0YWdzOiB7IHR5cGU6ICdrZXl3b3JkJyB9XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLmxvZ2dlci5kZWJ1ZygndG9kb19wbHVnaW46IENyZWF0ZWQgdG9kb3MgaW5kZXgnKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgdGhpcy5sb2dnZXIuZXJyb3IoJ0ZhaWxlZCB0byBpbml0aWFsaXplIHRvZG9zIGluZGV4OicsIGVycm9yKTtcbiAgICAgIHRocm93IGVycm9yOyAvLyBSZS10aHJvdyB0byBlbnN1cmUgc2V0dXAgZmFpbHMgaWYgaW5kZXggY3JlYXRpb24gZmFpbHNcbiAgICB9XG4gIH1cblxuICBwdWJsaWMgc3RhcnQoY29yZTogQ29yZVN0YXJ0KSB7XG4gICAgdGhpcy5sb2dnZXIuZGVidWcoJ3RvZG9fcGx1Z2luOiBTdGFydGVkJyk7XG4gICAgcmV0dXJuIHt9O1xuICB9XG5cbiAgcHVibGljIHN0b3AoKSB7IH1cbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBU0EsSUFBQUEsT0FBQSxHQUFBQyxPQUFBO0FBQXdDLFNBQUFDLGdCQUFBQyxHQUFBLEVBQUFDLEdBQUEsRUFBQUMsS0FBQSxJQUFBRCxHQUFBLEdBQUFFLGNBQUEsQ0FBQUYsR0FBQSxPQUFBQSxHQUFBLElBQUFELEdBQUEsSUFBQUksTUFBQSxDQUFBQyxjQUFBLENBQUFMLEdBQUEsRUFBQUMsR0FBQSxJQUFBQyxLQUFBLEVBQUFBLEtBQUEsRUFBQUksVUFBQSxRQUFBQyxZQUFBLFFBQUFDLFFBQUEsb0JBQUFSLEdBQUEsQ0FBQUMsR0FBQSxJQUFBQyxLQUFBLFdBQUFGLEdBQUE7QUFBQSxTQUFBRyxlQUFBTSxHQUFBLFFBQUFSLEdBQUEsR0FBQVMsWUFBQSxDQUFBRCxHQUFBLDJCQUFBUixHQUFBLGdCQUFBQSxHQUFBLEdBQUFVLE1BQUEsQ0FBQVYsR0FBQTtBQUFBLFNBQUFTLGFBQUFFLEtBQUEsRUFBQUMsSUFBQSxlQUFBRCxLQUFBLGlCQUFBQSxLQUFBLGtCQUFBQSxLQUFBLE1BQUFFLElBQUEsR0FBQUYsS0FBQSxDQUFBRyxNQUFBLENBQUFDLFdBQUEsT0FBQUYsSUFBQSxLQUFBRyxTQUFBLFFBQUFDLEdBQUEsR0FBQUosSUFBQSxDQUFBSyxJQUFBLENBQUFQLEtBQUEsRUFBQUMsSUFBQSwyQkFBQUssR0FBQSxzQkFBQUEsR0FBQSxZQUFBRSxTQUFBLDREQUFBUCxJQUFBLGdCQUFBRixNQUFBLEdBQUFVLE1BQUEsRUFBQVQsS0FBQTtBQUVqQyxNQUFNVSxVQUFVLENBQytCO0VBR3BEQyxXQUFXQSxDQUFDQyxrQkFBNEMsRUFBRTtJQUFBekIsZUFBQTtJQUN4RCxJQUFJLENBQUMwQixNQUFNLEdBQUdELGtCQUFrQixDQUFDQyxNQUFNLENBQUNDLEdBQUcsQ0FBQyxDQUFDO0VBQy9DO0VBRUEsTUFBYUMsS0FBS0EsQ0FBQ0MsSUFBZSxFQUFFO0lBQ2xDLElBQUksQ0FBQ0gsTUFBTSxDQUFDSSxLQUFLLENBQUMsb0JBQW9CLENBQUM7SUFDdkM7SUFDQSxNQUFNRCxJQUFJLENBQUNFLFVBQVUsQ0FBQ0MsY0FBYyxDQUFDLENBQUM7SUFFdEMsTUFBTUMsTUFBTSxHQUFHSixJQUFJLENBQUNLLElBQUksQ0FBQ0MsWUFBWSxDQUFDLENBQUM7O0lBRXZDO0lBQ0EsSUFBQUMsb0JBQVksRUFBQ0gsTUFBTSxDQUFDOztJQUVwQjtJQUNBLE1BQU0sSUFBSSxDQUFDSSxlQUFlLENBQUNSLElBQUksQ0FBQztJQUVoQyxPQUFPLENBQUMsQ0FBQztFQUNYO0VBRUEsTUFBY1EsZUFBZUEsQ0FBQ1IsSUFBZSxFQUFFO0lBQzdDLElBQUk7TUFDRixNQUFNUyxNQUFNLEdBQUdULElBQUksQ0FBQ0UsVUFBVSxDQUFDTyxNQUFNLENBQUNDLGFBQWE7TUFFbkQsTUFBTUMsV0FBVyxHQUFHLE1BQU1GLE1BQU0sQ0FBQ0csT0FBTyxDQUFDQyxNQUFNLENBQUM7UUFBRUMsS0FBSyxFQUFFO01BQVEsQ0FBQyxDQUFDO01BRW5FLElBQUksQ0FBQ0gsV0FBVyxDQUFDSSxJQUFJLEVBQUU7UUFDckIsTUFBTU4sTUFBTSxDQUFDRyxPQUFPLENBQUNJLE1BQU0sQ0FBQztVQUMxQkYsS0FBSyxFQUFFLE9BQU87VUFDZEMsSUFBSSxFQUFFO1lBQ0pFLFFBQVEsRUFBRTtjQUNSQyxVQUFVLEVBQUU7Z0JBQ1ZDLEtBQUssRUFBRTtrQkFBRUMsSUFBSSxFQUFFO2dCQUFPLENBQUM7Z0JBQ3ZCQyxNQUFNLEVBQUU7a0JBQUVELElBQUksRUFBRTtnQkFBVSxDQUFDO2dCQUMzQkUsU0FBUyxFQUFFO2tCQUFFRixJQUFJLEVBQUU7Z0JBQU8sQ0FBQztnQkFDM0JHLFdBQVcsRUFBRTtrQkFBRUgsSUFBSSxFQUFFO2dCQUFPLENBQUM7Z0JBQzdCSSxPQUFPLEVBQUU7a0JBQUVKLElBQUksRUFBRTtnQkFBTyxDQUFDO2dCQUN6QkssUUFBUSxFQUFFO2tCQUFFTCxJQUFJLEVBQUU7Z0JBQVUsQ0FBQztnQkFDN0JNLFdBQVcsRUFBRTtrQkFBRU4sSUFBSSxFQUFFO2dCQUFPLENBQUM7Z0JBQzdCTyxJQUFJLEVBQUU7a0JBQUVQLElBQUksRUFBRTtnQkFBVTtjQUMxQjtZQUNGO1VBQ0Y7UUFDRixDQUFDLENBQUM7UUFDRixJQUFJLENBQUN2QixNQUFNLENBQUNJLEtBQUssQ0FBQyxrQ0FBa0MsQ0FBQztNQUN2RDtJQUNGLENBQUMsQ0FBQyxPQUFPMkIsS0FBSyxFQUFFO01BQ2QsSUFBSSxDQUFDL0IsTUFBTSxDQUFDK0IsS0FBSyxDQUFDLG1DQUFtQyxFQUFFQSxLQUFLLENBQUM7TUFDN0QsTUFBTUEsS0FBSyxDQUFDLENBQUM7SUFDZjtFQUNGOztFQUVPQyxLQUFLQSxDQUFDN0IsSUFBZSxFQUFFO0lBQzVCLElBQUksQ0FBQ0gsTUFBTSxDQUFDSSxLQUFLLENBQUMsc0JBQXNCLENBQUM7SUFDekMsT0FBTyxDQUFDLENBQUM7RUFDWDtFQUVPNkIsSUFBSUEsQ0FBQSxFQUFHLENBQUU7QUFDbEI7QUFBQ0MsT0FBQSxDQUFBckMsVUFBQSxHQUFBQSxVQUFBIn0=